#include <stdio.h>

int main() {
    printf("Hello, Astra Linux!\n");
    return 0;
}
